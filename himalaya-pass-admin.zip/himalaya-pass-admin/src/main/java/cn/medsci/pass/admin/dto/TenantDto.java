package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class TenantDto {
    @ApiModelProperty(value = "id")
    private String id;
    /**
     * 项目编号
     */
    @ApiModelProperty(value = "企业类型id")
    private Integer tenant_type;

    /**
     * 项目名称
     */
    @ApiModelProperty(value = "项目名称")
    private String name;

    @ApiModelProperty(value = "企业类型名称")
    private String tenantTypeName;


    @ApiModelProperty(value = "企业名称缩写")
    private String shortName;

    @ApiModelProperty(value = "国家")
    private String country;


    @ApiModelProperty(value = "省")
    private String province;


    @ApiModelProperty(value = "城市")
    private String city;


    @ApiModelProperty(value = "地址")
    private String address;


    @ApiModelProperty(value = "邮编")
    private String zipcode;


    @ApiModelProperty(value = "logo文件id")
    private String logoFileId;

    @ApiModelProperty(value = "报告编号企业标识")
    private String reportMark;

    public String getReportMark() {
        return reportMark;
    }

    public void setReportMark(String reportMark) {
        this.reportMark = reportMark;
    }

    public String getLogoFileId() {
        return logoFileId;
    }

    public void setLogoFileId(String logoFileId) {
        this.logoFileId = logoFileId;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getTenantTypeName() {
        return tenantTypeName;
    }

    public void setTenantTypeName(String tenantTypeName) {
        this.tenantTypeName = tenantTypeName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getTenant_type() {
        return tenant_type;
    }

    public void setTenant_type(Integer tenant_type) {
        this.tenant_type = tenant_type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
