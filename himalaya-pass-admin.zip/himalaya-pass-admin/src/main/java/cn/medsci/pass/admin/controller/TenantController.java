package cn.medsci.pass.admin.controller;

import cn.medsci.common.msg.ObjectRestResponse;
import cn.medsci.pass.admin.dto.*;
import cn.medsci.pass.admin.entity.*;
import cn.medsci.pass.admin.service.SaasTenantService;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.mybatisplus.plugins.Page;
import io.swagger.annotations.ApiOperation;
import org.apache.servicecomb.provider.rest.common.RestSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import com.alibaba.fastjson.JSON;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@RestSchema(schemaId = "Tenant")
@RequestMapping(path = "Tenant")
public class TenantController {

    private static final Logger LOGGER = LoggerFactory.getLogger(TenantController.class);

    @Autowired
    private SaasTenantService saasTenantService;

    @GetMapping(path = "GetTenant/{tenantId}")
    @ApiOperation(value = "获取租户信息")
    public ObjectRestResponse<TenantDto> GetTenant(@PathVariable String tenantId) {
        ObjectRestResponse<TenantDto> response = new ObjectRestResponse<>();
        try {
            if (StringUtils.isEmpty(tenantId)) {
                response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
                response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
                return response;
            }
            SaasTenant tenant = saasTenantService.selectById(tenantId);
            if (tenant == null || StringUtils.isEmpty(tenantId)) {
                response.setStatus(AdminResultEnum.NO_DATA.getCode());
                response.setMessage(AdminResultEnum.NO_DATA.getMsg());
                return response;
            }
            TenantDto data = new TenantDto();
            BeanUtils.copyProperties(tenant, data);
            data.setId(tenant.getId());
            data.setName(tenant.getName());
            data.setTenant_type(tenant.getTenantType());
            data.setTenantTypeName(TenantTypeEnum.FromInteger(tenant.getTenantType()).getMsg());
            response.setData(data);
            return response;
        } catch (Exception ex) {
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        } finally {
            return response;
        }
    }

    @GetMapping(path = "GetTenantJson/{tenantId}")
    @ApiOperation(value = "获取租户信息")
    public String GetTenantJson(@PathVariable String tenantId) {
        ObjectRestResponse<TenantDto> response = new ObjectRestResponse<>();
        try {
            if (StringUtils.isEmpty(tenantId)) {
                response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
                response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
            }
            SaasTenant tenant = saasTenantService.selectById(tenantId);
            if (tenant == null || StringUtils.isEmpty(tenantId)) {
                response.setStatus(AdminResultEnum.NO_DATA.getCode());
                response.setMessage(AdminResultEnum.NO_DATA.getMsg());
            }
            TenantDto data = new TenantDto();
            BeanUtils.copyProperties(tenant, data);
            data.setId(tenant.getId());
            data.setName(tenant.getName());
            data.setTenant_type(tenant.getTenantType());
            data.setTenantTypeName(TenantTypeEnum.FromInteger(tenant.getTenantType()).getMsg());
            response.setData(data);
        } catch (Exception ex) {
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        } finally {
            String result = JSON.toJSONString(response, SerializerFeature.WriteMapNullValue);
            return result;
        }
    }

    @PostMapping(path = "getTenantPage")
    @ApiOperation(value = "获取企业分页信息")
    public ObjectRestPagerResponse<List<TenantDto>> getTenantPage(@RequestBody GetTenantPage request,
                                                                  @RequestParam(value = "key",required = false) String key){
        ObjectRestPagerResponse<List<TenantDto>> response = new ObjectRestPagerResponse<>();

        Page<SaasTenant> data;
        if(StringUtils.isEmpty(key) || key == null){
             data = saasTenantService.getTenantPage(request);
        }else {
            data = saasTenantService.getTenantPageLikeKey(request,key);
        }
        if(data ==null || data.getSize() ==0){
            response.setStatus(AdminResultEnum.NO_DATA.getCode());
            response.setMessage(AdminResultEnum.NO_DATA.getMsg());
            return response;
        }
        response.setTotalSize(data.getTotal());
        List<TenantDto> returnDta = new ArrayList<>();
        for (SaasTenant st : data.getRecords()) {
            TenantDto td = new TenantDto();
            BeanUtils.copyProperties(st, td);
            returnDta.add(td);
        }

        response.setData(returnDta);
        return response;
    }

    @PostMapping(path = "insertTenant")
    @ApiOperation(value = "新增租户")
    public ObjectRestResponse insertTenant(@RequestBody PostInsertTenantDto request){
        ObjectRestResponse response = new ObjectRestResponse<>();
        //校验数据的格式及有效性
        //TODO
        try {
            SaasTenant saasTenant = new SaasTenant();
            BeanUtils.copyProperties(request,saasTenant);
            Integer count = saasTenantService.insertTenant(saasTenant);
            if(count != 1){
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
                return response;
            }
        }catch (Exception ex){
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }

    @PutMapping("updateTenant")
    @ApiOperation(value = "更新租户信息")
    public ObjectRestResponse updateTenant(@RequestBody UpdateTenantDto request,@RequestParam(value = "file",required = false) MultipartFile file){
        ObjectRestResponse response = new ObjectRestResponse<>();
        try {
            Boolean result;
            SaasTenant saasTenant = new SaasTenant();
            BeanUtils.copyProperties(request,saasTenant);
            saasTenant.setUpdTime(new Date());

            //判断是否修改log图片
            if (file == null){
                result = saasTenantService.insertOrUpdate(saasTenant);
            }else {
                result = saasTenantService.updateTenant(saasTenant,file);
            }
            if (result == null || result == false){
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
                return response;
            }
        }catch (Exception ex){
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;

    }

    @DeleteMapping("delete/{tenantId}")
    @ApiOperation(value = "根据id删除租户")
    public ObjectRestResponse deleteTenant(@PathVariable String tenantId){
        ObjectRestResponse response = new ObjectRestResponse<>();
        try {
            Boolean result = saasTenantService.deleteTenant(tenantId);
            if (result == null || result != true ){
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
                return response;
            }
        }catch (Exception ex){
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }
}

