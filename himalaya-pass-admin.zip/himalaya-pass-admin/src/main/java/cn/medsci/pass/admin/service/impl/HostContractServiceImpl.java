package cn.medsci.pass.admin.service.impl;

import cn.medsci.pass.admin.entity.HostContract;
import cn.medsci.pass.admin.mapper.HostContractMapper;
import cn.medsci.pass.admin.service.HostContractService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@Service
public class HostContractServiceImpl extends ServiceImpl<HostContractMapper, HostContract> implements HostContractService {

}
