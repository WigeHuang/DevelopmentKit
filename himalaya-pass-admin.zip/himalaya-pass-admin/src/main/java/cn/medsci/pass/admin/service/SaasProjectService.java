package cn.medsci.pass.admin.service;

import cn.medsci.pass.admin.dto.GetProjectPageDto;
import cn.medsci.pass.admin.dto.ProjectDto;
import cn.medsci.pass.admin.entity.SaasProject;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface SaasProjectService extends IService<SaasProject> {

	Page<ProjectDto> getProjectPage(GetProjectPageDto request);

	Integer insertProject(SaasProject saasProject);

	Boolean deleteProjectById(String projectId);

}
