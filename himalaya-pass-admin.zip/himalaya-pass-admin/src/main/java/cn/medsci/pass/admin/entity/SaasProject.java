package cn.medsci.pass.admin.entity;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@TableName("saas_project")
public class SaasProject extends Model<SaasProject> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 租户id
     */
    @TableField("tenant_id")
    private String tenantId;
    /**
     * 运营项目id
     */
    @TableField("host_projectid")
    private String hostProjectid;
    /**
     * 项目编号
     */
    private String code;
    /**
     * 项目名称
     */
    private String name;
    /**
     * 修改人
     */
    @TableField("upd_name")
    private String updName;
    /**
     * 创建时间
     */
    @TableField("crt_time")
    private Date crtTime;
    /**
     * 创建人
     */
    @TableField("crt_name")
    private String crtName;
    /**
     * 修改时间
     */
    @TableField("upd_time")
    private Date updTime;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getHostProjectid() {
        return hostProjectid;
    }

    public void setHostProjectid(String hostProjectid) {
        this.hostProjectid = hostProjectid;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUpdName() {
        return updName;
    }

    public void setUpdName(String updName) {
        this.updName = updName;
    }

    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public String getCrtName() {
        return crtName;
    }

    public void setCrtName(String crtName) {
        this.crtName = crtName;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "SaasProject{" +
        ", id=" + id +
        ", tenantId=" + tenantId +
        ", hostProjectid=" + hostProjectid +
        ", code=" + code +
        ", name=" + name +
        ", updName=" + updName +
        ", crtTime=" + crtTime +
        ", crtName=" + crtName +
        ", updTime=" + updTime +
        "}";
    }
}
