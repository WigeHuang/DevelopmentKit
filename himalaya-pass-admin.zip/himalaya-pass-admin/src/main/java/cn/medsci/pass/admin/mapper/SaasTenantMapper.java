package cn.medsci.pass.admin.mapper;

import cn.medsci.pass.admin.dto.GetTenantPage;
import cn.medsci.pass.admin.entity.SaasTenant;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface SaasTenantMapper extends BaseMapper<SaasTenant> {

    List<SaasTenant> GetTenantPage(Page<SaasTenant> page, @Param("tenant") GetTenantPage tenant);

    List<SaasTenant> GetTenantPageLikeKey(Page<SaasTenant> page,  @Param("tenant")GetTenantPage tenant,  @Param("key")String key);
}
