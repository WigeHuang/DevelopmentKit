package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

public class GetTenant {

    @ApiModelProperty(value = "租户id")
    private String tenantId;

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }
}
