package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

public class ProjectDto {
    @ApiModelProperty(value = "项目id")
    private String id;


    /**
     * 项目编号
     */
    @ApiModelProperty(value = "项目编号")
    private String code;

    /**
     * 项目名称
     */
    @ApiModelProperty(value = "项目名称")
    private String name;
    /**
     * 项目编号
     */
    @ApiModelProperty(value = "企业名称")
    private String tenantName;

    /**
     * 项目名称
     */
    @ApiModelProperty(value = "运营项目编号")
    private String hostProjectCode;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public String getHostProjectCode() {
		return hostProjectCode;
	}

	public void setHostProjectCode(String hostProjectCode) {
		this.hostProjectCode = hostProjectCode;
	}
}
