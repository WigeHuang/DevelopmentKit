package cn.medsci.pass.admin.entity;

public enum  AdminResultEnum {

UNKONW_ERROR(-1,"未知错误"),
SUCCESS(200,"成功"),
ERROR(100,"失败"),

NO_DATA(600, "没有数据"),

REQUEST_NO_DATA(601, "请求数据为空");

private Integer code;
private String msg;

AdminResultEnum(Integer code, String msg) {
this.code = code;
this.msg = msg;
}

public Integer getCode() {
return code;
}

public String getMsg() {
return msg;
}
}

