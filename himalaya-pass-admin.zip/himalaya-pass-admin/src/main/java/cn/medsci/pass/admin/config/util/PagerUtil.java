package cn.medsci.pass.admin.config.util;

import cn.medsci.pass.admin.dto.PagerDto;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

public  class PagerUtil{
    public static Pagination PagerToPaination(PagerDto pager){
        Pagination ret = new Pagination(pager.getPageIndex(), pager.getPageSize());
        return  ret;
    }
}
