package cn.medsci.pass.admin.dto;

public class GetProjectPageDto extends PagerDto {
	
    private String key;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
