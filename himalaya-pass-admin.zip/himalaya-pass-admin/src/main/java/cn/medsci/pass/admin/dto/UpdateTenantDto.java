package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

public class UpdateTenantDto {
    private String id;
    //不可修改的数据
//    /**
//     * 1 药企 2 CRO 3医院
//     */
//    @ApiModelProperty(value = "企业类型")
//    private Integer tenantType;
//    /**
//     * 企业名称
//     */
//    @ApiModelProperty(value = "企业名称")
//    private String name;
//    /**
//     * 名称缩写
//     */
//    @ApiModelProperty(value = "名称缩写")
//    private String shortName;
//    /**
//     * 企业标识
//     */
//    @ApiModelProperty(value = "企业标识")
//    private String code;
    /**
     * 国家
     */
    @ApiModelProperty(value = "国家")
    private String country;
    /**
     * 城市
     */
    @ApiModelProperty(value = "城市")
    private String city;
    /**
     * 地址
     */
    @ApiModelProperty(value = "地址")
    private String address;
    /**
     * 邮编
     */
    @ApiModelProperty(value = "邮编")
    private String zipcode;
    /**
     * 域名
     */
    @ApiModelProperty(value = "域名")
    private String domainName;
    /**
     * 公司logoid
     */
    @ApiModelProperty(value = "公司log")
    private String logoFileid;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getLogoFileid() {
        return logoFileid;
    }

    public void setLogoFileid(String logoFileid) {
        this.logoFileid = logoFileid;
    }
}
