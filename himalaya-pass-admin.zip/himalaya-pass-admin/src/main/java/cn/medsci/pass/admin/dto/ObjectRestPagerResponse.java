package cn.medsci.pass.admin.dto;

import cn.medsci.common.msg.ObjectRestResponse;

public class ObjectRestPagerResponse<T>  extends ObjectRestResponse<T>
{
    private int totalSize;

    public int getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(int totalSize) {
        this.totalSize = totalSize;
    }
}
