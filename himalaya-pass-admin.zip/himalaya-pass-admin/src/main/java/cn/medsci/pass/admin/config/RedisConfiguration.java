package cn.medsci.pass.admin.config;//package cn.medsci.auth.server.config;
//
//import cn.medsci.auth.server.config.util.RedisObjectSerializer;
//import com.baomidou.mybatisplus.toolkit.StringUtils;
//import com.fasterxml.jackson.annotation.JsonAutoDetect;
//import com.fasterxml.jackson.annotation.PropertyAccessor;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.Data;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.data.redis.connection.RedisConnectionFactory;
//import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.data.redis.serializer.*;
//import redis.clients.jedis.JedisPoolConfig;
//
//import java.net.UnknownHostException;
//
///**
// * ${DESCRIPTION}
// *
// * @author wanghaobin
// * @create 2017-06-21 8:39
// */
//
//@Configuration
//@Data
//public class RedisConfiguration {
//
//
//
//
////    @Primary
////    @Bean("redisTemplate")
////    // 没有此属性就不会装配bean 如果是单个redis 将此注解注释掉
////    @ConditionalOnProperty(name = "spring.redis.cluster.nodes", matchIfMissing = false)
////    public RedisTemplate<String, Object> getRedisTemplate(RedisConnectionFactory factory) {
////        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
////        redisTemplate.setConnectionFactory(factory);
////
////        RedisSerializer stringSerializer = new StringRedisSerializer();
////        // RedisSerializer redisObjectSerializer = new RedisObjectSerializer();
////        RedisSerializer redisObjectSerializer = new RedisObjectSerializer();
////        redisTemplate.setKeySerializer(stringSerializer); // key的序列化类型
////        redisTemplate.setHashKeySerializer(stringSerializer);
////        redisTemplate.setValueSerializer(redisObjectSerializer); // value的序列化类型
////        redisTemplate.afterPropertiesSet();
////
////        redisTemplate.opsForValue().set("hello", "wolrd");
////        return redisTemplate;
////    }
//
//    @Primary
//    @Bean("redisTemplate")
//    @ConditionalOnProperty(name = "spring.redis.host", matchIfMissing = true)
//    public RedisTemplate<String, Object> getSingleRedisTemplate(RedisConnectionFactory factory) {
//        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
//        redisTemplate.setConnectionFactory(factory);
//        redisTemplate.setKeySerializer(new StringRedisSerializer()); // key的序列化类型
//        redisTemplate.setValueSerializer(new RedisObjectSerializer()); // value的序列化类型
//        redisTemplate.afterPropertiesSet();
//        return redisTemplate;
//    }
//
//
//
////
////    @Bean(name = "redisConnectionFactory")
////    public RedisConnectionFactory connectionFactory() {
////        return this.ConnectionFactory(
////                hostName,
////                password,
////                index,
////                port,
////                timeout,
////                maxIdle,
////                minIdle,
////                maxTotal,
////                maxWaitMillis,
////                testOnBorrow);
////    }
////
////    /**
////     * 构造RedisConnectionFactory
////     *
////     * @param hostName      host
////     * @param password      pwd
////     * @param index         db index
////     * @param port          端口
////     * @param timeout       连接超时时间
////     * @param maxIdle       max-Idle
////     * @param minIdle       min-Idle
////     * @param maxTotal      最大连接数
////     * @param maxWaitMillis 最大等待毫秒数
////     * @param testOnBorrow  test
////     * @return RedisConnectionFactory
////     */
////    private RedisConnectionFactory ConnectionFactory(String hostName,
////                                                     String password,
////                                                     int index,
////                                                     int port,
////                                                     int timeout,
////                                                     int maxIdle,
////                                                     int minIdle,
////                                                     int maxTotal,
////                                                     long maxWaitMillis,
////                                                     boolean testOnBorrow) {
////        JedisConnectionFactory jedis = new JedisConnectionFactory();
////        jedis.setHostName(hostName);
////        jedis.setPort(port);
////        jedis.setTimeout(timeout);
////        if (StringUtils.isNotEmpty(password)) {
////            jedis.setPassword(password);
////        }
////        if (index != 0) {
////            jedis.setDatabase(index);
////        }
////        jedis.setPoolConfig(poolCofig(maxIdle, maxTotal, maxWaitMillis, minIdle, testOnBorrow));
////        // 初始化连接pool
////        jedis.afterPropertiesSet();
////        RedisConnectionFactory factory = jedis;
////        return factory;
////    }
////
////    @Bean
////    public JedisPoolConfig getPoolConfig(){
////        return poolCofig(maxIdle, maxTotal, maxWaitMillis, minIdle, testOnBorrow);
////    }
////
////    private static JedisPoolConfig poolCofig(int maxIdle,
////                                             int maxTotal,
////                                             long maxWaitMillis,
////                                             int minIdle,
////                                             boolean testOnBorrow) {
////        JedisPoolConfig poolCofig = new JedisPoolConfig();
////        poolCofig.setMaxIdle(maxIdle);
////        poolCofig.setMaxTotal(maxTotal);
////        poolCofig.setMaxWaitMillis(maxWaitMillis);
////        poolCofig.setMinIdle(minIdle);
////        poolCofig.setTestOnBorrow(testOnBorrow);
////        return poolCofig;
////    }
//
//
//
//
//}
