package cn.medsci.pass.admin.mapper;

import cn.medsci.pass.admin.entity.SaasUser;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface SaasUserMapper extends BaseMapper<SaasUser> {

 SaasUser getUserByUsername(String userName);

}
