package cn.medsci.pass.admin.service;

import cn.medsci.pass.admin.dto.GetTenantPage;
import cn.medsci.pass.admin.entity.SaasTenant;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface SaasTenantService extends IService<SaasTenant> {

    Integer insertTenant(SaasTenant saasTenant);

    Boolean deleteTenant(String tenantId);

    Boolean updateTenant(SaasTenant saasTenant, MultipartFile file);

    Page<SaasTenant> getTenantPage(GetTenantPage request);

    Page<SaasTenant> getTenantPageLikeKey(GetTenantPage request, String key);
}
