package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

public class UpdateUserPwdDto {
    @ApiModelProperty(value = "用户id")
    private String userId;

    @ApiModelProperty(value = "用户新密码")
    private String password;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
