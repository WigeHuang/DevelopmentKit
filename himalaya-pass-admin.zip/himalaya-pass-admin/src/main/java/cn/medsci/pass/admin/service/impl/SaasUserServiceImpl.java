package cn.medsci.pass.admin.service.impl;


import cn.medsci.pass.admin.entity.SaasProject;
import cn.medsci.pass.admin.entity.SaasProjectUser;
import cn.medsci.pass.admin.entity.SaasUser;
import cn.medsci.pass.admin.mapper.SaasUserMapper;
import cn.medsci.pass.admin.service.SaasProjectService;
import cn.medsci.pass.admin.service.SaasProjectUserService;
import cn.medsci.pass.admin.service.SaasUserService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@Service
public class SaasUserServiceImpl extends ServiceImpl<SaasUserMapper, SaasUser> implements SaasUserService {

    @Autowired
    private SaasProjectService saasProjectService;

    @Autowired
    private SaasProjectUserService saasProjectUserService;

    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    @Override
    public Integer updateUserPwd(String userId, String password) {
        SaasUser user = new SaasUser();
        user.setId(userId);
        String encodedPwd =encoder.encode(password);
        user.setPassword(encodedPwd);
        //Boolean matches = encoder.matches(password, encodedPwd);
        return  baseMapper.updateById(user);
    }

    @Override
    public SaasUser queryUserByUsernameAndPassword(String username, String password) {
        //根据用户名查询
        SaasUser dbUser = baseMapper.getUserByUsername(username);
        if(dbUser == null){
            return null;
        }
        //判断密码是否正确
        String encodePassword = encoder.encode(password);
        if(!StringUtils.equals(encodePassword,dbUser.getPassword())){
            //密码错误
            return null;
        }
        return dbUser;
    }

    @Override
    @Transactional
    public Boolean insertUser(SaasUser saasUser, String projectId) {
        Boolean result = false;
        try {
            //查询项目是否存在
            SaasProject saasProject = saasProjectService.selectById(projectId);
            if (saasProject == null){
                //不存在则新增项目
                SaasProject project = new SaasProject();
                project.setId(projectId);
                project.setCrtTime(new Date());
                saasProjectService.insert(project);
            }

            //新增时设置用户数据
            saasUser.setCrtTime(new Date());
            saasUser.setUserStatus(1);
            baseMapper.insert(saasUser);

            //设置中间表数据
            //ID怎么设置（自增长），对象中是否会自动返回id的值
            SaasProjectUser saasProjectUser = new SaasProjectUser();
            saasProjectUser.setSassUserId(saasUser.getId());
            saasProjectUser.setSassProjectId(projectId);
            saasProjectUserService.insert(saasProjectUser);

            //设置新增数据成功返回值
            result = true;
        }catch (Exception e){
            result = false;
            throw new RuntimeException(e);
        }finally {
            return result;
        }
    }
}
