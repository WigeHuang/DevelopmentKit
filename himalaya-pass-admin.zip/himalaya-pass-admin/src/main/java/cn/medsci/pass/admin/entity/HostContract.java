package cn.medsci.pass.admin.entity;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@TableName("host_contract")
public class HostContract extends Model<HostContract> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 租户Id
     */
    @TableField("tenant_id")
    private String tenantId;
    /**
     * 开始日期
     */
    @TableField("start_date")
    private Date startDate;
    /**
     * 结束日期
     */
    @TableField("end_date")
    private Date endDate;
    /**
     * 生效日期
     */
    @TableField("effect_date")
    private Date effectDate;
    @TableField("serial_number")
    private String serialNumber;
    /**
     * 创建时间
     */
    @TableField("crt_time")
    private Date crtTime;
    /**
     * 创建人
     */
    @TableField("crt_name")
    private String crtName;
    /**
     * 修改时间
     */
    @TableField("upd_time")
    private Date updTime;
    /**
     * 修改人
     */
    @TableField("upd_name")
    private String updName;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getEffectDate() {
        return effectDate;
    }

    public void setEffectDate(Date effectDate) {
        this.effectDate = effectDate;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public String getCrtName() {
        return crtName;
    }

    public void setCrtName(String crtName) {
        this.crtName = crtName;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdName() {
        return updName;
    }

    public void setUpdName(String updName) {
        this.updName = updName;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "HostContract{" +
        ", id=" + id +
        ", tenantId=" + tenantId +
        ", startDate=" + startDate +
        ", endDate=" + endDate +
        ", effectDate=" + effectDate +
        ", serialNumber=" + serialNumber +
        ", crtTime=" + crtTime +
        ", crtName=" + crtName +
        ", updTime=" + updTime +
        ", updName=" + updName +
        "}";
    }
}
