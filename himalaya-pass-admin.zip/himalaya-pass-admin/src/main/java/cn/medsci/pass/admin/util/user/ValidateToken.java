package cn.medsci.pass.admin.util.user;

import io.swagger.annotations.ApiModelProperty;

public class ValidateToken {

    @ApiModelProperty(value = "token")
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
