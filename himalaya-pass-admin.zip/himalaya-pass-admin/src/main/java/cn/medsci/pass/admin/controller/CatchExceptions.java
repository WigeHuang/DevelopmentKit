package cn.medsci.pass.admin.controller;

import cn.medsci.common.msg.BaseResponse;
import cn.medsci.pass.admin.entity.AdminBusinessException;
import cn.medsci.pass.admin.entity.AdminResultEnum;
import org.slf4j.Logger;

/**
 * 获取自定义异常
 */
public abstract class CatchExceptions {

    public static void catchOtherException(Logger logger, Exception e, BaseResponse response){
        if (e instanceof AdminBusinessException) {
            AdminBusinessException ue = (AdminBusinessException) e;
            response.setMessage(ue.getMessage());
            response.setStatus(ue.getStatus());
        } else {
            logger.error(e.getMessage());
            AdminResultEnum result = AdminResultEnum.UNKONW_ERROR;
            response.setMessage(result.getMsg());
            response.setStatus(result.getCode());
        }
    }
}
