package cn.medsci.pass.admin.controller;


import cn.medsci.common.msg.ObjectRestResponse;
import cn.medsci.pass.admin.dto.*;
import cn.medsci.pass.admin.entity.AdminResultEnum;
import cn.medsci.pass.admin.entity.SaasUser;
import cn.medsci.pass.admin.service.SaasUserService;
import io.swagger.annotations.ApiOperation;
import org.apache.servicecomb.provider.rest.common.RestSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@RestSchema(schemaId = "User")
@RequestMapping(path = "User")
public class UserController {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private SaasUserService userService;

    @PostMapping(path = "UpdateUserPwd")
    @ApiOperation(value = "更新用户密码")
    public ObjectRestPagerResponse UpdateUserPwd(@RequestBody UpdateUserPwdDto request) {
        ObjectRestPagerResponse response = new ObjectRestPagerResponse();
        if (StringUtils.isEmpty(request.getUserId()) || StringUtils.isEmpty(request.getPassword())) {
            response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
            response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
            return response;
        }
        try {
            Integer ret = userService.updateUserPwd(request.getUserId(), request.getPassword());
            if (ret == 0) {
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
            }
        } catch (Exception ex) {
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }

//    /**
//     * 根据用户密码查询
//     */
//    @ApiOperation(value = "根据用户密码查询")
//    @GetMapping("queryUserByUsernameAndPassword")
//    public ObjectRestResponse<SaasUserDto> queryUserByUsernameAndPassword(@RequestBody GetUserByUsernameAndPasswordDto request) {
//        ObjectRestResponse<SaasUserDto> response = new ObjectRestResponse<>();
//        try {
//            SaasUser saasUser = userService.queryUserByUsernameAndPassword(request.getUsername(),request.getPassword());
//            if(saasUser == null){
//                response.setStatus(AdminResultEnum.NO_DATA.getCode());
//                response.setMessage(AdminResultEnum.NO_DATA.getMsg());
//                return response;
//            }
//            //返回页面需要的数据
//            SaasUserDto saasUserDto = new SaasUserDto();
//            BeanUtils.copyProperties(saasUser,saasUserDto);
//            response.setData(saasUserDto);
//        }catch (Exception ex){
//            CatchExceptions.catchOtherException(LOGGER,ex,response);
//        }finally {
//            return response;
//        }
//    }

    /**
     * 新增用户
     */
    @ApiOperation(value = "新增用户")
    @PostMapping("insertUser")
    public ObjectRestResponse insertUser(@RequestBody PostInsertUserDto request) {
        ObjectRestResponse response = new ObjectRestResponse<>();
        //校验数据的格式及有效性,hibernate
        //TODO
        try {
            SaasUser saasUser = new SaasUser();
            BeanUtils.copyProperties(request,saasUser);
            Boolean result = userService.insertUser(saasUser, request.getProjectId());
            if (result==null || result==false){
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
                return response;
            }
        }catch (Exception ex){
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }finally {
            return response;
        }
    }

}
