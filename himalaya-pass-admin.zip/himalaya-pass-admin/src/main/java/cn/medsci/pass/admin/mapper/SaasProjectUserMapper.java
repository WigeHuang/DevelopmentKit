package cn.medsci.pass.admin.mapper;

import cn.medsci.pass.admin.dto.GetProjectUsers;
import cn.medsci.pass.admin.dto.GetUsers;
import cn.medsci.pass.admin.dto.GetUsersByIds;
import cn.medsci.pass.admin.entity.SaasProjectUser;
import cn.medsci.pass.admin.entity.SaasUser;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface SaasProjectUserMapper extends BaseMapper<SaasProjectUser> {
    List<SaasUser> GetProjectUserPage(Page<SaasUser> page, @Param("user") GetProjectUsers user);

    List<SaasUser> GetUsersPage(Page<SaasUser>page, @Param("user") GetUsers user);

    List<SaasUser> GetUsersByIdsPage(Page<SaasUser>page, @Param("user") GetUsersByIds user);
    
    Integer deleteByProjectId(@Param("projectId")String projectId);
}
