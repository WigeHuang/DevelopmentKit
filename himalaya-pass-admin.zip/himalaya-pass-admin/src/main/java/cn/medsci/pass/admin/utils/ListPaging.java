package cn.medsci.pass.admin.utils;

import java.util.ArrayList;
import java.util.List;


public class ListPaging<T> {
    List<?> list;
    int pageSize;

    public ListPaging() {

    }

    /**
     * 初始化
     *
     * @param list
     *            数据库查询到的数据集合
     * @param pageSize
     *            每页显示的记录条数
     */
    public ListPaging(List<?> list, int pageSize) {
        this.list = list;
        this.pageSize = pageSize;
    }

    /**
     * 返回当前页的记录集合
     *
     * @param pageIndex
     *            当前页
     * @return 当前页的List集合(页数从0开始)
     */
    @SuppressWarnings("unchecked")
    public List<T> getPaging(int pageIndex) {
        // 总记录条数
        int count = list.size();
        // 分页集合
        List<Object> list = new ArrayList<Object>();
        for (int i = 0; i < count; i += pageSize) {
            List<Object> temp = new ArrayList<Object>();
            if ((count - i) >= pageSize) {
                for (int j = 0; j < pageSize; j++) {
                    temp.add(this.list.get(i + j));
                }
            } else {
                for (int j = 0; j < count - i; j++) {
                    temp.add(this.list.get(i + j));
                }
            }
            list.add(temp);
        }
        // 返回当前页
        return (List<T>) list.get(pageIndex);
    }

    public int getPageNum() {
        // 总记录条数
        int count = list.size();
        // 分页数
        int pageNum = count / pageSize;
        if (count % pageSize != 0) {
            pageNum += 1;
        }
        return pageNum;
    }
}