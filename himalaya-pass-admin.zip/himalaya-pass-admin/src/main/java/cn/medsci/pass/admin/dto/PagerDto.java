package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

public class PagerDto {
    @ApiModelProperty(value = "pageIndex", notes="起始为0")
    private int pageIndex;

    @ApiModelProperty(value = "每页的条数")
    private int pageSize;

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }


}
