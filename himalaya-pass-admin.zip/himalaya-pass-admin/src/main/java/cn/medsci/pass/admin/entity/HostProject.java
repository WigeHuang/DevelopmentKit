package cn.medsci.pass.admin.entity;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@TableName("host_project")
public class HostProject extends Model<HostProject> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 产品id
     */
    @TableField("product_id")
    private String productId;
    /**
     * 产品版本
     */
    @TableField("product_version")
    private Integer productVersion;
    /**
     * 使用人数上限
     */
    @TableField("max_user_num")
    private Integer maxUserNum;
    /**
     * 开始时间
     */
    @TableField("start_date")
    private Date startDate;
    /**
     * 开始时间
     */
    @TableField("end_date")
    private Date endDate;
    private String url;
    /**
     * 状态 0 未开始 1进行中 2已结束
     */
    private Integer status;
    /**
     * 创建时间
     */
    @TableField("crt_time")
    private Date crtTime;
    /**
     * 创建人
     */
    @TableField("crt_name")
    private String crtName;
    /**
     * 修改时间
     */
    @TableField("upd_time")
    private Date updTime;
    /**
     * 修改人
     */
    @TableField("upd_name")
    private String updName;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }




    public Integer getProductVersion() {
        return productVersion;
    }

    public void setProductVersion(Integer productVersion) {
        this.productVersion = productVersion;
    }

    public Integer getMaxUserNum() {
        return maxUserNum;
    }

    public void setMaxUserNum(Integer maxUserNum) {
        this.maxUserNum = maxUserNum;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }



    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public String getCrtName() {
        return crtName;
    }

    public void setCrtName(String crtName) {
        this.crtName = crtName;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdName() {
        return updName;
    }

    public void setUpdName(String updName) {
        this.updName = updName;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    @Override
    public String toString() {
        return "HostProject{" +
        ", id=" + id +
        ", productId=" + productId +
        ", productVersion=" + productVersion +
        ", maxUserNum=" + maxUserNum +
        ", startDate=" + startDate +
        ", endDate=" + endDate +
        ", url=" + url +
        ", status=" + status +
        ", productId=" + productId +
        ", crtTime=" + crtTime +
        ", crtName=" + crtName +
        ", updTime=" + updTime +
        ", updName=" + updName +
        "}";
    }
}
