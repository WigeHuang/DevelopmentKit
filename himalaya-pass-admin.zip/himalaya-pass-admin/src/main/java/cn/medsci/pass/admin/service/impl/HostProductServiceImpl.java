package cn.medsci.pass.admin.service.impl;

import cn.medsci.pass.admin.entity.HostProduct;
import cn.medsci.pass.admin.mapper.HostProductMapper;
import cn.medsci.pass.admin.service.HostProductService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@Service
public class HostProductServiceImpl extends ServiceImpl<HostProductMapper, HostProduct> implements HostProductService {

}
