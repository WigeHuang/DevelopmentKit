package cn.medsci.pass.admin.mapper;

import cn.medsci.pass.admin.dto.GetProjectPageDto;
import cn.medsci.pass.admin.dto.ProjectDto;
import cn.medsci.pass.admin.entity.SaasProject;

import java.util.List;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface SaasProjectMapper extends BaseMapper<SaasProject> {

	List<ProjectDto> getProjectPage(Page<ProjectDto> page, GetProjectPageDto request);

}
