package cn.medsci.pass.admin.entity;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@TableName("saas_user")
public class SaasUser extends Model<SaasUser> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 租户id
     */
    @TableField("tenant_id")
    private String tenantId;
    /**
     * 用户名
     */
    @TableField("user_name")
    private String userName;
    /**
     * 真实姓名
     */
    @TableField("real_name")
    private String realName;
    /**
     * 密码
     */
    private String password;
    /**
     * 手机号码
     */
    @TableField("mobile_phone")
    private String mobilePhone;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 1 男 0 女
     */
    private String sex;
    /**
     * 性别
     */
    @TableField("user_status")
    private Integer userStatus;
    /**
     * 用户状态1正常2禁用
     */
    private String description;
    /**
     * 创建时间
     */
    @TableField("crt_time")
    private Date crtTime;
    /**
     * 创建人
     */
    @TableField("crt_name")
    private String crtName;
    /**
     * 修改时间
     */
    @TableField("upd_time")
    private Date updTime;
    /**
     * 修改人
     */
    @TableField("upd_name")
    private String updName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(Integer userStatus) {
        this.userStatus = userStatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public String getCrtName() {
        return crtName;
    }

    public void setCrtName(String crtName) {
        this.crtName = crtName;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdName() {
        return updName;
    }

    public void setUpdName(String updName) {
        this.updName = updName;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "SaasUser{" +
        ", id=" + id +
        ", tenantId=" + tenantId +
        ", userName=" + userName +
        ", realName=" + realName +
        ", password=" + password +
        ", mobilePhone=" + mobilePhone +
        ", email=" + email +
        ", sex=" + sex +
        ", userStatus=" + userStatus +
        ", description=" + description +
        ", crtTime=" + crtTime +
        ", crtName=" + crtName +
        ", updTime=" + updTime +
        ", updName=" + updName +
        "}";
    }
}
