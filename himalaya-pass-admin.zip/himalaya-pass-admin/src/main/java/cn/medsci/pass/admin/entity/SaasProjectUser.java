package cn.medsci.pass.admin.entity;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@TableName("saas_project_user")
public class SaasProjectUser extends Model<SaasProjectUser> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 项目id
     */
    @TableField("sass_project_id")
    private String sassProjectId;
    /**
     * 用户id
     */
    @TableField("sass_user_id")
    private String sassUserId;
    /**
     * 创建时间
     */
    @TableField("crt_time")
    private Date crtTime;
    /**
     * 创建人
     */
    @TableField("crt_name")
    private String crtName;
    /**
     * 修改时间
     */
    @TableField("upd_time")
    private Date updTime;
    /**
     * 修改人
     */
    @TableField("upd_name")
    private String updName;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSassProjectId() {
        return sassProjectId;
    }

    public void setSassProjectId(String sassProjectId) {
        this.sassProjectId = sassProjectId;
    }

    public String getSassUserId() {
        return sassUserId;
    }

    public void setSassUserId(String sassUserId) {
        this.sassUserId = sassUserId;
    }

    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public String getCrtName() {
        return crtName;
    }

    public void setCrtName(String crtName) {
        this.crtName = crtName;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdName() {
        return updName;
    }

    public void setUpdName(String updName) {
        this.updName = updName;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "SaasProjectUser{" +
        ", id=" + id +
        ", sassProjectId=" + sassProjectId +
        ", sassUserId=" + sassUserId +
        ", crtTime=" + crtTime +
        ", crtName=" + crtName +
        ", updTime=" + updTime +
        ", updName=" + updName +
        "}";
    }
}
