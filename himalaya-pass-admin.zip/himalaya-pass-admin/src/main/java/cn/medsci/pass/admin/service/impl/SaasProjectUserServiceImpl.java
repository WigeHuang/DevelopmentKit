package cn.medsci.pass.admin.service.impl;

import cn.medsci.pass.admin.dto.GetProjectUsers;
import cn.medsci.pass.admin.dto.GetUsers;
import cn.medsci.pass.admin.dto.GetUsersByIds;
import cn.medsci.pass.admin.entity.SaasProjectUser;
import cn.medsci.pass.admin.entity.SaasUser;
import cn.medsci.pass.admin.mapper.SaasProjectUserMapper;
import cn.medsci.pass.admin.service.SaasProjectUserService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@Service
public class SaasProjectUserServiceImpl extends ServiceImpl<SaasProjectUserMapper, SaasProjectUser> implements SaasProjectUserService {

    @Override
    public Page<SaasUser> GetProjectUserPage(GetProjectUsers request) {
        Page<SaasUser> page = new Page<>(request.getPageIndex(), request.getPageSize());
        page.setOptimizeCountSql(false);
        List<SaasUser> users = baseMapper.GetProjectUserPage(page, request);
        Page<SaasUser> ret= page.setRecords(users);
        ret.setTotal(page.getTotal());
        return  ret;
    }

    @Override
    public Page<SaasUser> GetUsersPage(GetUsers request) {
        Page<SaasUser> page = new Page<>(request.getPageIndex(), request.getPageSize());
        List<SaasUser> users = baseMapper.GetUsersPage(page,request);
        Page<SaasUser> ret= page.setRecords(users);
        return  ret;
    }

    @Override
    @Transactional(readOnly=true)
    public Page<SaasUser> GetUsersByIdsPage(GetUsersByIds request) {
        Page<SaasUser> page = new Page<>(request.getPageIndex(), request.getPageSize());
        List<SaasUser> users = baseMapper.GetUsersByIdsPage(page, request);
        Page<SaasUser> ret= page.setRecords(users);
        return ret;
    }

	@Override
	public Integer deleteByProjectId(String projectId) {
		
		return baseMapper.deleteByProjectId(projectId);
	}

}
