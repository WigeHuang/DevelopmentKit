package cn.medsci.pass.admin.entity.enums;

public enum UserStatusEnum {

    //用户状态1正常2禁用


}
