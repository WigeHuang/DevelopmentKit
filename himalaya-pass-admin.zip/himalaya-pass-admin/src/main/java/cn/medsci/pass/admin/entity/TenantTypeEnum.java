package cn.medsci.pass.admin.entity;

/*
租户类型
*/
public enum TenantTypeEnum {

    yaoqi (1,"药企"),
    CRO (2,"CRO"),
    HISTORY (3,"医院");

    private Integer code;
    private String msg;

    TenantTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static TenantTypeEnum FromInteger(int x) {
        switch(x) {
            case 1:
                return yaoqi;
            case 2:
                return CRO;
            case 3:
                return HISTORY;
        }
        return null;
    }

}
