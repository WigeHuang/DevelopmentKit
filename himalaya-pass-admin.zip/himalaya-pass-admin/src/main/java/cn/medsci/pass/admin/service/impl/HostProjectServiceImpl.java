package cn.medsci.pass.admin.service.impl;

import cn.medsci.pass.admin.entity.HostProject;
import cn.medsci.pass.admin.mapper.HostProjectMapper;
import cn.medsci.pass.admin.service.HostProjectService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@Service
public class HostProjectServiceImpl extends ServiceImpl<HostProjectMapper, HostProject> implements HostProjectService {

}
