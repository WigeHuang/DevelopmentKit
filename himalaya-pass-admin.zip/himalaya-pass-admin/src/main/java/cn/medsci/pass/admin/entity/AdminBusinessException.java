package cn.medsci.pass.admin.entity;

import cn.medsci.common.exception.BaseException;

public class AdminBusinessException  extends BaseException {

    public AdminBusinessException(AdminResultEnum resultEnum) {
        super(resultEnum.getMsg());
        this.setStatus(resultEnum.getCode());
    }

}
