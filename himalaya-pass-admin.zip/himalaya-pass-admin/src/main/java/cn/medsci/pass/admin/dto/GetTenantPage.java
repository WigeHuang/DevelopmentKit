package cn.medsci.pass.admin.dto;

public class GetTenantPage extends PagerDto{

}
