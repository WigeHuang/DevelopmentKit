package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

public class GetProject {
    @ApiModelProperty(value = "项目id")
    private  String projectId;

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }
}
