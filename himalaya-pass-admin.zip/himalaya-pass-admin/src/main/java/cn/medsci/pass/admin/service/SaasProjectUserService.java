package cn.medsci.pass.admin.service;

import cn.medsci.pass.admin.dto.GetProjectUsers;
import cn.medsci.pass.admin.dto.GetUsers;
import cn.medsci.pass.admin.dto.GetUsersByIds;
import cn.medsci.pass.admin.entity.SaasProjectUser;
import cn.medsci.pass.admin.entity.SaasUser;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface SaasProjectUserService extends IService<SaasProjectUser> {
    Page<SaasUser> GetProjectUserPage(GetProjectUsers request);

    Page<SaasUser> GetUsersPage(GetUsers request);

    Page<SaasUser> GetUsersByIdsPage(GetUsersByIds request);

	Integer deleteByProjectId(@Param("projectId")String projectId);
}
