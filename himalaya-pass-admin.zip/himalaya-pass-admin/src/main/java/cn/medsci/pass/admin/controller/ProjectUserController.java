package cn.medsci.pass.admin.controller;

import cn.medsci.pass.admin.dto.*;
import cn.medsci.pass.admin.entity.AdminResultEnum;
import cn.medsci.pass.admin.entity.SaasUser;
import cn.medsci.pass.admin.service.SaasProjectUserService;
import com.baomidou.mybatisplus.plugins.Page;
import io.swagger.annotations.ApiOperation;
import org.apache.servicecomb.provider.rest.common.RestSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestSchema(schemaId = "ProjectUser")
@RequestMapping(path = "ProjectUser")
public class ProjectUserController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProjectUserController.class);
    @Autowired
    private SaasProjectUserService saasProjectUserService;

    @PostMapping(path = "GetProjectUsers")
    @ApiOperation(value = "获取项目用户列表", notes="返回Java类型")
    public ObjectRestPagerResponse<List<SaasUserDto>> GetProjectUsers(@RequestBody GetProjectUsers request) {
        ObjectRestPagerResponse<List<SaasUserDto>> response = new ObjectRestPagerResponse<>();
        if (StringUtils.isEmpty(request.getProjectId()) || request.getPageSize() ==0) {
            response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
            response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
            return response;
        }
        try {
            Page<SaasUser> data =saasProjectUserService.GetProjectUserPage(request);;
            if(data ==null || data.getSize() ==0){
                response.setStatus(AdminResultEnum.NO_DATA.getCode());
                response.setMessage(AdminResultEnum.NO_DATA.getMsg());
                return response;
            }
            response.setTotalSize(data.getTotal());
            List<SaasUserDto> returnDta = new ArrayList<>();
            for (SaasUser su : data.getRecords()) {
                SaasUserDto item = new SaasUserDto();
                BeanUtils.copyProperties(su, item);
                returnDta.add(item);
            }
            response.setData(returnDta);
        } catch (Exception ex) {
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }

    @PostMapping(path = "GetUsers")
    @ApiOperation(value = "用户管理，获取用户列表")
    public ObjectRestPagerResponse<List<SaasUserDto>> GetUsers(@RequestBody GetUsers request){
        ObjectRestPagerResponse<List<SaasUserDto>> response = new ObjectRestPagerResponse<>();
        if (StringUtils.isEmpty(request.getProjectId()) || request.getPageSize() ==0 ) {
            response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
            response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
            return response;
        }
        try {
            Page<SaasUser> data =saasProjectUserService.GetUsersPage(request);;
            if(data ==null || data.getSize() ==0){
                response.setStatus(AdminResultEnum.NO_DATA.getCode());
                response.setMessage(AdminResultEnum.NO_DATA.getMsg());
                return response;
            }
            response.setTotalSize(data.getTotal());
            List<SaasUserDto> returnDta = new ArrayList<>();
            for (SaasUser su : data.getRecords()) {
                SaasUserDto item = new SaasUserDto();
                BeanUtils.copyProperties(su, item);
                returnDta.add(item);
            }
            response.setData(returnDta);
        } catch (Exception ex) {
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }

    @PostMapping(path = "GetUsersByIds")
    @ApiOperation(value = "根据用户的id列表返回用户信息")
    public ObjectRestPagerResponse<List<SaasUserDto>> GetUsersByIds(@RequestBody GetUsersByIds request){
        ObjectRestPagerResponse<List<SaasUserDto>> response = new ObjectRestPagerResponse<>();
        try {
            Page<SaasUser> data =saasProjectUserService.GetUsersByIdsPage(request);;
            if(data ==null ||data.getSize() ==0){
                response.setStatus(AdminResultEnum.NO_DATA.getCode());
                response.setMessage(AdminResultEnum.NO_DATA.getMsg());
                return response;
            }
            response.setTotalSize(data.getTotal());
            List<SaasUserDto> returnDta = new ArrayList<>();
            for (SaasUser su : data.getRecords()) {
                SaasUserDto item = new SaasUserDto();
                BeanUtils.copyProperties(su, item);
                returnDta.add(item);
            }
            response.setData(returnDta);
        } catch (Exception ex) {
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }
}

