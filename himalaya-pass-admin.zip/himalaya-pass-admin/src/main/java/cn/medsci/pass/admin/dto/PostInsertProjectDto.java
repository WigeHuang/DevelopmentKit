package cn.medsci.pass.admin.dto;

import com.baomidou.mybatisplus.annotations.TableField;

import io.swagger.annotations.ApiModelProperty;

public class PostInsertProjectDto {
    /**
     * 租户id
     */
    @ApiModelProperty(value = "租户id")
    private String tenantId;
    /**
     * 运营项目id
     */
    @ApiModelProperty(value = "运营项目id")
    private String hostProjectid;
    /**
     * 项目编号
     */
    @ApiModelProperty(value = "项目编号")
    private String code;
    /**
     * 项目名称
     */
    @ApiModelProperty(value = "项目名称")
    private String name;
	/**
     * 创建人
     */
    @TableField("crt_name")
    private String crtName;

	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getHostProjectid() {
		return hostProjectid;
	}
	public void setHostProjectid(String hostProjectid) {
		this.hostProjectid = hostProjectid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
    public String getCrtName() {
		return crtName;
	}
	public void setCrtName(String crtName) {
		this.crtName = crtName;
	}
}
