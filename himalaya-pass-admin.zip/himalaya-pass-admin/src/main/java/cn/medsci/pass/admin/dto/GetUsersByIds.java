package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;

public class GetUsersByIds extends  PagerDto{

    @ApiModelProperty(value = "用户id列表", allowEmptyValue = true)
    private List<String> userIds;


    @ApiModelProperty(value = "项目id", allowEmptyValue = false)
    private String projectId;

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public List<String> getUserIds() {
        return userIds;
    }

    public void setUserIds(List<String> userIds) {
        this.userIds = userIds;
    }
}
