package cn.medsci.pass.admin.service;

import cn.medsci.pass.admin.entity.SaasUser;
import com.baomidou.mybatisplus.service.IService;

public interface SaasUserService extends IService<SaasUser> {

    Integer updateUserPwd(String userId, String password);

    SaasUser queryUserByUsernameAndPassword(String username, String password);

    Boolean insertUser(SaasUser saasUser, String projectId);
}
