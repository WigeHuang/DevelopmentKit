package cn.medsci.pass.admin.controller;

import cn.medsci.common.msg.ObjectRestResponse;
import cn.medsci.pass.admin.dto.GetProjectPageDto;
import cn.medsci.pass.admin.dto.GetTenantPage;
import cn.medsci.pass.admin.dto.ObjectRestPagerResponse;
import cn.medsci.pass.admin.dto.PostInsertProjectDto;
import cn.medsci.pass.admin.dto.PostInsertTenantDto;
import cn.medsci.pass.admin.dto.ProjectDto;
import cn.medsci.pass.admin.dto.TenantDto;
import cn.medsci.pass.admin.dto.UpdateProjectDto;
import cn.medsci.pass.admin.dto.UpdateTenantDto;
import cn.medsci.pass.admin.entity.AdminResultEnum;
import cn.medsci.pass.admin.entity.SaasProject;
import cn.medsci.pass.admin.entity.SaasTenant;
import cn.medsci.pass.admin.service.SaasProjectService;
import io.swagger.annotations.ApiOperation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.servicecomb.provider.rest.common.RestSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.plugins.Page;

@RestSchema(schemaId = "Project")
@RequestMapping(path = "Project")
public class ProjectController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProjectController.class);

    @Autowired
    private SaasProjectService saasProjectService;

    @ApiOperation(value = "获取项目信息")
    @RequestMapping(value = "/GetProject/{projectId}",method = RequestMethod.GET)
    public ObjectRestResponse<ProjectDto> GetProject(@PathVariable String projectId) {
        ObjectRestResponse<ProjectDto> response = new ObjectRestResponse<>();
        try {
            if (StringUtils.isEmpty(projectId)) {
                response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
                response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
            }
            SaasProject project = saasProjectService.selectById(projectId);
            if (project==null || StringUtils.isEmpty(projectId)) {
                response.setStatus(AdminResultEnum.NO_DATA.getCode());
                response.setMessage(AdminResultEnum.NO_DATA.getMsg());
            }
            ProjectDto data = new ProjectDto();
            data.setId(project.getId());
            data.setCode(project.getCode());
            data.setName(project.getName());
            response.setData(data);
            return response;
        } catch (Exception ex) {
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }
    
    @GetMapping(path = "getProjectPage")
    @ApiOperation(value = "获取项目分页信息")
    public ObjectRestPagerResponse<List<ProjectDto>> getProjectPage(@RequestBody GetProjectPageDto request){
        ObjectRestPagerResponse<List<ProjectDto>> response = new ObjectRestPagerResponse<>();

        Page<ProjectDto> data = saasProjectService.getProjectPage(request);
        if(data ==null || data.getSize() ==0){
            response.setStatus(AdminResultEnum.NO_DATA.getCode());
            response.setMessage(AdminResultEnum.NO_DATA.getMsg());
            return response;
        }
        response.setTotalSize(data.getTotal());
        response.setData(data.getRecords());
        return response;
    }
    
    @PostMapping(path = "insertProject")
    @ApiOperation(value = "新增项目")
    public ObjectRestResponse insertProject(@RequestBody PostInsertProjectDto request){
        ObjectRestResponse response = new ObjectRestResponse<>();
        
        try {
            SaasProject saasProject = new SaasProject();
            BeanUtils.copyProperties(request,saasProject);
            Integer count = saasProjectService.insertProject(saasProject);
            if(count != 1){
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
                return response;
            }
        }catch (Exception ex){
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }

    @PutMapping("updateProject")
    @ApiOperation(value = "更新项目信息")
    public ObjectRestResponse updateProject(@RequestBody UpdateProjectDto request){
        ObjectRestResponse response = new ObjectRestResponse<>();
        try {
        	if(StringUtils.isEmpty(request.getId())) {
        		response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
                response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
                return response;
        	}
        	
            Boolean result;
            SaasProject saasProject = new SaasProject();
            BeanUtils.copyProperties(request,saasProject);
            saasProject.setUpdTime(new Date());

            result = saasProjectService.insertOrUpdate(saasProject);
       
            if (!result){
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
                return response;
            }
        }catch (Exception ex){
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;

    }

    @DeleteMapping("delete/{projectId}")
    @ApiOperation(value = "根据id删除项目")
    public ObjectRestResponse deleteProject(@PathVariable String projectId){
        ObjectRestResponse response = new ObjectRestResponse<>();
        try {
        	if(StringUtils.isEmpty(projectId)) {
        		 response.setStatus(AdminResultEnum.REQUEST_NO_DATA.getCode());
                 response.setMessage(AdminResultEnum.REQUEST_NO_DATA.getMsg());
                 return response;
        	}
            Boolean result = saasProjectService.deleteProjectById(projectId);
            if (!result){
                response.setStatus(AdminResultEnum.ERROR.getCode());
                response.setMessage(AdminResultEnum.ERROR.getMsg());
                return response;
            }
        }catch (Exception ex){
            CatchExceptions.catchOtherException(LOGGER,ex,response);
        }
        return response;
    }
 }

