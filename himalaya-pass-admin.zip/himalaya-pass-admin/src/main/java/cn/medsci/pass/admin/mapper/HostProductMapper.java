package cn.medsci.pass.admin.mapper;

import cn.medsci.pass.admin.entity.HostProduct;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface HostProductMapper extends BaseMapper<HostProduct> {

}
