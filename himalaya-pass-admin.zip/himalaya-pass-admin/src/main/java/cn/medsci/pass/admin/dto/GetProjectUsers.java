package cn.medsci.pass.admin.dto;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class GetProjectUsers extends PagerDto {
    @ApiModelProperty(value = "项目id")
    private String projectId;

    @ApiModelProperty(value = "用户名")
    private String userName;

    @ApiModelProperty(value = "用户真实姓名")
    private String realName;

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }


}
