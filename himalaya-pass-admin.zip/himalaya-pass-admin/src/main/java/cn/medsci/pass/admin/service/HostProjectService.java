package cn.medsci.pass.admin.service;

import cn.medsci.pass.admin.entity.HostProject;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
public interface HostProjectService extends IService<HostProject> {

}
