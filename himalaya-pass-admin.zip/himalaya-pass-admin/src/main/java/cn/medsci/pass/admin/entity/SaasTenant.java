package cn.medsci.pass.admin.entity;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@TableName("saas_tenant")
public class SaasTenant extends Model<SaasTenant> {

    private static final long serialVersionUID = 1L;

    private String id;
    /**
     * 企业名称
     */
    private String name;
    /**
     * 企业标识
     */
    private String code;
    /**
     * 国家
     */
    private String country;
    /**
     * 城市
     */
    private String city;
    /**
     * 地址
     */
    private String address;
    /**
     * 邮编
     */
    private String zipcode;
    /**
     * 域名
     */
    @TableField("domain_name")
    private String domainName;
    /**
     * 1 药企 2 CRO 3医院
     */
    @TableField("tenant_type")
    private Integer tenantType;
    /**
     * 创建时间
     */
    @TableField("crt_time")
    private Date crtTime;
    /**
     * 创建人
     */
    @TableField("crt_name")
    private String crtName;
    /**
     * 修改时间
     */
    @TableField("upd_time")
    private Date updTime;
    /**
     * 修改人
     */
    @TableField("upd_name")
    private String updName;
    /**
     * 名称缩写
     */
    @TableField("short_name")
    private String shortName;
    /**
     * 公司logoid
     */
    @TableField("logo_fileId")
    private String logoFileid;

    @TableField("report_Mark")
    private String reportMark;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getReportMark() {
        return reportMark;
    }

    public void setReportMark(String reportMark) {
        this.reportMark = reportMark;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public Integer getTenantType() {
        return tenantType;
    }

    public void setTenantType(Integer tenantType) {
        this.tenantType = tenantType;
    }

    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public String getCrtName() {
        return crtName;
    }

    public void setCrtName(String crtName) {
        this.crtName = crtName;
    }

    public Date getUpdTime() {
        return updTime;
    }

    public void setUpdTime(Date updTime) {
        this.updTime = updTime;
    }

    public String getUpdName() {
        return updName;
    }

    public void setUpdName(String updName) {
        this.updName = updName;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getLogoFileid() {
        return logoFileid;
    }

    public void setLogoFileid(String logoFileid) {
        this.logoFileid = logoFileid;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "SaasTenant{" +
        ", id=" + id +
        ", name=" + name +
        ", code=" + code +
        ", country=" + country +
        ", city=" + city +
        ", address=" + address +
        ", zipcode=" + zipcode +
        ", domainName=" + domainName +
        ", tenantType=" + tenantType +
        ", crtTime=" + crtTime +
        ", crtName=" + crtName +
        ", updTime=" + updTime +
        ", updName=" + updName +
        ", shortName=" + shortName +
        ", logoFileid=" + logoFileid +
        "}";
    }
}
