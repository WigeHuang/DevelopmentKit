package cn.medsci.pass.admin.service.impl;


import cn.medsci.pass.admin.dto.GetTenantPage;
import cn.medsci.pass.admin.entity.SaasProject;
import cn.medsci.pass.admin.entity.SaasTenant;
import cn.medsci.pass.admin.entity.SaasUser;
import cn.medsci.pass.admin.mapper.SaasTenantMapper;
import cn.medsci.pass.admin.service.SaasProjectService;
import cn.medsci.pass.admin.service.SaasTenantService;
import cn.medsci.pass.admin.service.SaasUserService;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@Service
public class SaasTenantServiceImpl extends ServiceImpl<SaasTenantMapper, SaasTenant> implements SaasTenantService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SaasTenantServiceImpl.class);

    @Autowired
    SaasProjectService saasProjectService;

    @Autowired
    SaasUserService saasUserService;

    @Override
    public Integer insertTenant(SaasTenant saasTenant) {

        //添加业务及其他相关数据
        saasTenant.setCrtTime(new Date());
        return baseMapper.insert(saasTenant);
    }

    @Override
    @Transactional
    public Boolean deleteTenant(String tenantId) {

        //删除租户前，将用户和项目表中的租户id置为null;
        Boolean result;
        try {
            //1.查询租户下的用户的租户id，设置为空
            List<SaasUser> saasUsers = saasUserService.selectList(new EntityWrapper<SaasUser>().eq("tenantId",tenantId));
            saasUsers.forEach(user ->user.setTenantId(null));
            //更新用户
            saasUserService.insertOrUpdateAllColumnBatch(saasUsers);

            //2.查询租户的项目，项目中的租户id设置为空
            List<SaasProject> saasProjects = saasProjectService.selectList(new EntityWrapper<SaasProject>().eq("tenantId", tenantId));
            saasProjects.forEach(project->project.setTenantId(null));
            saasProjectService.insertOrUpdateAllColumnBatch(saasProjects);

            //根据id删除租户信息
            baseMapper.deleteById(tenantId);
            result =true;
        }catch (Exception e){
            result = false;
            LOGGER.error(e.getMessage());
            throw new RuntimeException(e);
        }
        return result;
    }

    @Override
    public Boolean updateTenant(SaasTenant saasTenant, MultipartFile file) {
        //修改数据
        Boolean result;
        try {
            //上传log图片,返回图片地址
            String url = this.uploadImage(file);
            if (url==null || StringUtils.isEmpty(url)){
                return null;
            }
            saasTenant.setLogoFileid(url);
            this.insertOrUpdate(saasTenant);
            result = true;
        }catch (Exception e){
            LOGGER.error(e.getMessage());
            result = false;
        }
        return result;
    }

    @Override
    public Page<SaasTenant> getTenantPage(GetTenantPage request) {
        Page<SaasTenant> page = new Page<>(request.getPageIndex(), request.getPageSize());
        List<SaasTenant> tenants = baseMapper.GetTenantPage(page,request);
        Page<SaasTenant> ret= page.setRecords(tenants);
        return ret;
    }

    @Override
    public Page<SaasTenant> getTenantPageLikeKey(GetTenantPage request, String key) {
        Page<SaasTenant> page = new Page<>(request.getPageIndex(), request.getPageSize());
        List<SaasTenant> tenants = baseMapper.GetTenantPageLikeKey(page,request,key);

        Page<SaasTenant> ret= page.setRecords(tenants);
        ret.setTotal(page.getTotal());
        return ret;
    }
}
