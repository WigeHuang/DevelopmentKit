package cn.medsci.pass.admin.service.impl;


import cn.medsci.pass.admin.dto.GetProjectPageDto;
import cn.medsci.pass.admin.dto.ProjectDto;
import cn.medsci.pass.admin.entity.SaasProject;
import cn.medsci.pass.admin.entity.SaasProjectUser;
import cn.medsci.pass.admin.entity.SaasUser;
import cn.medsci.pass.admin.mapper.SaasProjectMapper;
import cn.medsci.pass.admin.mapper.SaasProjectUserMapper;
import cn.medsci.pass.admin.service.SaasProjectService;
import cn.medsci.pass.admin.service.SaasProjectUserService;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author ${author}
 * @since 2018-08-09
 */
@Service
public class SaasProjectServiceImpl extends ServiceImpl<SaasProjectMapper, SaasProject> implements SaasProjectService {
	
	@Autowired
	private SaasProjectMapper saasProjectMapper;
	@Autowired
	private SaasProjectUserService saasProjectUserService;
	
	@Override
	public Page<ProjectDto> getProjectPage(GetProjectPageDto request) {
		Page<ProjectDto> page = new Page<>(request.getPageIndex(), request.getPageSize());
        List<ProjectDto> projects = saasProjectMapper.getProjectPage(page,request);
        page.setRecords(projects);
		return page;
	}

	@Override
	public Integer insertProject(SaasProject saasProject) {
		
		saasProject.setCrtTime(new Date());
		return saasProjectMapper.insert(saasProject);
	}

	@Override
	@Transactional
	public Boolean deleteProjectById(String projectId) {
		
		Integer count = saasProjectMapper.deleteById(projectId);
		if(count == 1) {
			saasProjectUserService.deleteByProjectId(projectId);
			return true;
		}
		return false;
	}

}
