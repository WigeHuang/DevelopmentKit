/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';
angular.module('serviceCenter')
	.controller('serviceCenterController', ['$scope', '$state', '$stateParams', '$translate',
		function($scope, $state, $stateParams, $translate){

			$scope.$state = $state;
			$scope.$stateParams = $stateParams;

			$scope.tenant  = localStorage.getItem("tenant") || "default";
			var tenant = document.getElementById("tenant");
			tenant.addEventListener("keydown", function (e) {
			    if (e.keyCode === 13) {
			        $scope.changeHeader(e);
			    }
			});

			$scope.changeHeader = function(e){
				var value = e.target.value;
				if(!value || value == '' || value == undefined) {
					return;
				}
				localStorage.setItem('tenant', value);
				$state.reload();
			};
			
			$scope.selectLang = function(language) {
			  if(language == null || language  == undefined){
				return;
			  }
		      localStorage.setItem("lang", language);
		      $scope.language = language;
		      $translate.use(language);
    		};

    		$scope.language  = localStorage.getItem("lang");
			if($scope.language == null || $scope.language == '' || $scope.language == undefined || $scope.language == "null") {
				$scope.language = "en";
			}
			
}]);	